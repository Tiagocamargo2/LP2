﻿namespace Pvestibular01
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRecebe = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lstbxTotal = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnRecebe
            // 
            this.btnRecebe.Location = new System.Drawing.Point(119, 96);
            this.btnRecebe.Name = "btnRecebe";
            this.btnRecebe.Size = new System.Drawing.Size(201, 93);
            this.btnRecebe.TabIndex = 0;
            this.btnRecebe.Text = "Receber Dados";
            this.btnRecebe.UseVisualStyleBackColor = true;
            this.btnRecebe.Click += new System.EventHandler(this.btnRecebe_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(119, 269);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(201, 88);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lstbxTotal
            // 
            this.lstbxTotal.FormattingEnabled = true;
            this.lstbxTotal.ItemHeight = 20;
            this.lstbxTotal.Location = new System.Drawing.Point(430, 22);
            this.lstbxTotal.Name = "lstbxTotal";
            this.lstbxTotal.Size = new System.Drawing.Size(388, 544);
            this.lstbxTotal.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 647);
            this.Controls.Add(this.lstbxTotal);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnRecebe);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRecebe;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.ListBox lstbxTotal;
    }
}

