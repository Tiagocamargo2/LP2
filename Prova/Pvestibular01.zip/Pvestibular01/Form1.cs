﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRecebe_Click(object sender, EventArgs e)
        {
            int[,] matriz = new int[3, 5];
            string auxiliar = "";
            int [] totalcurso = new int[5];
            
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a quantidade de alunos no ano{j + 1}", $"Curso {i + 1}");
                    if (!int.TryParse(auxiliar, out matriz[i, j]) || (matriz[i, j] < 0))
                    {
                        MessageBox.Show("Quantidade inválida");
                        j--;
                    }
                    else
                    {
                        totalcurso[i] += matriz[i, j];
                    }
                }
            }
            for (int i = 0; i < 3; i++)
            {
                for(int j = 0; j < 5; j++)
                {
                    lstbxTotal.Items.Add($"Total do curso {i+1} do ano {j+1}: {matriz[i, j]}");
                }
                lstbxTotal.Items.Add($"-----------total do curso {i + 1}:{totalcurso[i]}");

            }
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxTotal.Items.Clear();
        }
    }
}
